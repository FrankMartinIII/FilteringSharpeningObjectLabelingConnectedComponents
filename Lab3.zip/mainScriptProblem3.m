%Ryan George and Frank Martin 4/3/21
%This is just a script to test the connected components function with the
%blobsbin.gif image.
im = imread("blobsbin.gif");
figure, imshow(im);
img = im2gray(im);
sigma = 0.5;
imsmooth = imgaussfilt(img, sigma);
%figure, imshow(imsmooth);

[gradientMag, gradientDir] = imgradient(imsmooth);

thrs = 120;
edges = (gradientMag > thrs);
edgesvis = 255* uint8(edges);
figure, imshow(edgesvis);


imDim = size(im); %Get the dimensions of the image
imageX = imDim(1);
imageY = imDim(2);

[ccim, numbercc] = cclabel(edges);

for r = 1 : imageX
    for c = 1 : imageY
        if ccim(r,c) == 1
            ccim(r,c) = 70;
        elseif ccim(r,c) == 20
            ccim(r,c) = 150;
        elseif ccim(r,c) == 123
            ccim(r,c) = 255;
        end
    end
end

ccimdisp = uint8(ccim);

figure, imshow(ccimdisp);

imtest = img;
imtest = imtest  > thrs;
[ccim, numbercc] = cclabel(imtest);

for r = 1 : imageX
    for c = 1 : imageY
        if ccim(r,c) == 16
            ccim(r,c) = 100;
        elseif ccim(r,c) == 62
            ccim(r,c) = 170;
        elseif ccim(r,c) == 1
            ccim(r,c) = 255;
        end
    end
end

ccimdisp = uint8(ccim);

figure, imshow(ccimdisp);