%Ryan George and Frank Martin 4/3/21
%This is a script used for testing the sharpenimage1 and sharpenimage2
%functions with the image pig.png.
im = imread("pig.png")
img = rgb2gray(im)

%Sharpening the pig with sharpenimage1
figure,
subplot(3,3,1)
imshow(sharpenimage1(img, 1, 1))
subplot(3,3,2)
imshow(sharpenimage1(img, 1, 2))
subplot(3,3,3)
imshow(sharpenimage1(img, 1, 3))

subplot(3,3,4)
imshow(sharpenimage1(img, 3, 1))
subplot(3,3,5)
imshow(sharpenimage1(img, 3, 2))
subplot(3,3,6)
imshow(sharpenimage1(img, 3, 3))

subplot(3,3,7)
imshow(sharpenimage1(img, 7, 1))
subplot(3,3,8)
imshow(sharpenimage1(img, 7, 2))
subplot(3,3,9)
imshow(sharpenimage1(img, 7, 3))




%Sharpening the pig with sharpenimage2
figure,
subplot(3,3,1)
[~, ~, sharpim, ~, ~] = sharpenimage2(img, 1, 1);
imshow(sharpim)
subplot(3,3,2)
[~, ~, sharpim, ~, ~] = sharpenimage2(img, 1, 2);
imshow(sharpim)
subplot(3,3,3)
[~, ~, sharpim, ~, ~] = sharpenimage2(img, 1, 3);
imshow(sharpim)

subplot(3,3,4)
[~, ~, sharpim, ~, ~] = sharpenimage2(img, 3, 1);
imshow(sharpim)
subplot(3,3,5)
[~, ~, sharpim, ~, ~] = sharpenimage2(img, 3, 2);
imshow(sharpim)
subplot(3,3,6)
[~, ~, sharpim, ~, ~] = sharpenimage2(img, 3, 3);
imshow(sharpim)

subplot(3,3,7)
[~, ~, sharpim, ~, ~] = sharpenimage2(img, 7, 1);
imshow(sharpim)
subplot(3,3,8)
[~, ~, sharpim, ~, ~] = sharpenimage2(img, 7, 2);
imshow(sharpim)
subplot(3,3,9)
[~, ~, sharpim, ~, ~] = sharpenimage2(img, 7, 3);
imshow(sharpim)
%σ = 1, 3, 7 and α = 1, 2, 3
%sharpenimage1(img, sigma, alpha)