%Frank Martin and Ryan George 3/30/21
%Script for problem 1 of assignment 3. Used for convolving the
%decorgray.gif image with the various box filters specified.


im = imread("decorgray.gif");
img = im2gray(im);
imshow(img);
img = double(img); %convert image to grey and then cast to double


box3 = ones(3); %smoothing with a 3x3 box filter
box3 = box3/(3*3);
smooth3 = conv2(img, box3, 'same'); %using same to get image of the same size as the original
smooth3 = uint8(smooth3); %cast image back to uint8 to display
figure, imshow(smooth3);

box7 = ones(7);  %smoothing with a 7x7 box filter
box7 = box7/(7*7);
smooth7 = conv2(img, box7, 'same');
smooth7 = uint8(smooth7);
figure, imshow(smooth7);

box21 = ones(21);  %smoothing with a 21x21 box filter
box21 = box21/(21*21);
smooth21 = conv2(img, box21, 'same');
smooth21 = uint8(smooth21);
figure, imshow(smooth21);

box21x1 = ones(21,1); %smoothing with a 21x1 box filter
box21x1 = box21x1 / 21;
smooth21x1 = conv2(img, box21x1, 'same');
smooth21x1 = uint8(smooth21x1);
figure, imshow(smooth21x1);

box1x21 = ones(1,21); %smoothing with a 1x21 box filter
box1x21 = box1x21 / 21;
smooth1x21 = conv2(img, box1x21, 'same');
smooth1x21 = uint8(smooth1x21);
figure, imshow(smooth1x21);


