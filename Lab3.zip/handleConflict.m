%Frank Martin & Ryan George 4/2/21
%handleConflict is a function for use in the cclabel function. It takes as
%input equivMatrix, the equivalence matrix, equivVector, a vector that
%stores the equivalence classes that each number belongs to, the value of
%the left neigboring pixel, and the value of the upper neighboring pixel

function [equivMatrixEnd, equivVectorEnd] = handleConflict(equivMatrix, equivVector, leftNeighbor, upperNeighbor)
classA = equivVector(leftNeighbor);  %Look up the classes of each neighbor in the vector
classB = equivVector(upperNeighbor);

lowerClass = 0;
upperClass = 0; %Figure out which class is numerically lower so that the upper class can be merged into the lower class.
if classA <= classB
    lowerClass = classA;
    upperClass = classB;
else
    lowerClass = classB;
    upperClass = classA;
end

lowerRow = equivMatrix(lowerClass, :);  %Get row in equivalence matrix of each class
upperRow = equivMatrix(upperClass, :);

mergedRow = bitor(lowerRow, upperRow); %Merge the rows
zeroRow = mergedRow * 0; %Create a row of 0s
equivMatrix(lowerClass, : ) = mergedRow; %Insert the merged row into the lower class' position
equivMatrix(upperClass, : ) = zeroRow; %Replace the upper row's equiv classes with 0s

vecSize = size(equivVector);
%theForVal = vecSize(2)
for i = 1 : vecSize(2) %Iterate through the vector
    classX = equivVector(i);
    %classX
    if classX == upperClass
        equivVecBef = equivVector(i);
        %equivVecBef
        equivVector(i) = lowerClass;  %Note in the vector that the values that correspond with the upper equivalence class
                                        %now correspond with the lower one
        equivVecAft = equivVector(i);
        %equivVecAft
    end
end

equivVectorEnd = equivVector;
equivMatrixEnd = equivMatrix;

end