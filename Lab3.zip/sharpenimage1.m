%Frank Martin and Ryan George 4/2/21
%sharpenimage1 is a function used to enhance detail in the image. It takes
%3 inputs: img, sigma, and alpha.
%img is the input greyscale image.
%sigma is the standard deviation used fot the Gaussian which is used for
%smoothing the image.
%alpha is the value that the detail is multiplied by when it is added back
%to the original image to get the sharpened image.
%It returns sharpim, the sharpened image, blurred, the image that was
%smoothed with the Gaussian, and detail, the smoother image subtracted from
%the original image.

function [sharpim, blurred, detail] = sharpenimage1(img, sigma, alpha)
%im = imread("pig.png");
%img = im2gray(im);

%sigma = 3;
%alpha = 10;

imsmooth = imgaussfilt(img, sigma); %apply gaussian with specified sigma value to smooth the image.

detail = img - imsmooth; %get the detail by taking the original image and subtracting the smoothed image from it.

imsharp = img + (alpha*detail); %obtain the sharpened image by adding the detail multiplied by some alpha to the original image.

%imshow(imsharp);
sharpim = imsharp;
blurred = imsmooth;
end