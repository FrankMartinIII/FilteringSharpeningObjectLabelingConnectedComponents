%Frank Martin and Ryan George 4/2/21
%The cclabel function finds and labels the connected components of a binary
%image. Each connected component is given a unique label. cclabel takes as
%input im, a binary image. It returns ccim and numbercc. ccim is the image
%with different values at each pixel for each unique connected component.
%numbercc is the number of different connected components found and
%labelled.


function [ccim, numbercc] = cclabel(im)

%im = imread("blobsbin.gif")
%imshow(im)
%img = im2gray(im);
%sigma = 0.5;
%imsmooth = imgaussfilt(img, sigma);
%figure, imshow(imsmooth)

%[gradientMag, gradientDir] = imgradient(imsmooth);

%thrs = 120;
%edges = (gradientMag > thrs);
%edges = uint8(edges);
%figure, imshow(edges);

edges = im;
edges = uint8(edges);
imDim = size(im); %Get the dimensions of the image
imageX = imDim(1);
imageY = imDim(2);

%edges(1,1)
cc = 0; %Connected component counter

equivSize = imageX + imageY; 
equivTable = zeros(equivSize); %Set up the equivalence table. A 2D matrix to keep track of all equivalence classes.
equivVector = zeros(1,equivSize); %Set up equivalence vector. A vector that keeps track of the class that the connected component has been merged into.
%test = max(max(edges))


edges = uint16(edges);
for r = 1: imageX %Iterate through the image
    for c = 1: imageY
        %fprintf("r %d c %d " , r  , c)
        pix = edges(r,c);
        
        
        if pix == 1 %Pixel value of 1 means it is part of a component.
           

            if r == 1 %If the pixel's neighbors would go out of bounds, they are set to 0
                upperNeighbor = 0;
            else
                upperNeighbor = edges(r-1,c); 
            end
            
            if c == 1
                leftNeighbor = 0;
            else
                leftNeighbor = edges(r,c-1);
            end
                
            

            if (leftNeighbor >0) && (upperNeighbor == 0) %If left has value and upper does not, take left
                edges(r,c) = leftNeighbor;
                %fprintf("taking left val");

            elseif (upperNeighbor > 0) && (leftNeighbor == 0) %Opposite, take upper
                edges(r,c) = upperNeighbor;
                %fprintf("taking upper val");

            elseif (upperNeighbor == leftNeighbor) && (upperNeighbor > 0) %If upper and left are the same and not 0, doesnt matter which you take
                edges(r,c) = upperNeighbor;
                %fprintf("hello");

            elseif (upperNeighbor > 0) && (leftNeighbor > 0) && (upperNeighbor ~= leftNeighbor) %If upper and left are above 0 and belong to different components, there is a conflict.
                %fprintf("conflict");
                edges(r,c) = upperNeighbor;
                
                %Steps to perform
                %1. lookup what classes the two values are equivalent to, A
                %and B
                %2. Perform a bitwise or operation to merge class B into
                %class A in equivTable
                %3. Zero out class B
                %4. For every i which corresponded to class B, update their
                %value to class A
                
                [mat, vec] = handleConflict(equivTable, equivVector, leftNeighbor, upperNeighbor); %Use handleConflict function to perform (roughly) the steps above.
                equivTable = mat;
                equivVector = vec;
                
            else %New connected component starts.
                %fprintf("the otherwise case");
                cc = cc + 1; 


                edges(r,c) = cc;
                equivTable(cc, cc) = 1; %Mark the diagonal
                equivVector(cc) = cc; %Initially, in only its own set.

            end

            
            %edges(r,c)
        end
      
        
    end
    
    
    
end


for r = 1 : imageX %Go through the image again and set each pixel value that belongs to the same class to the same value.
    for c = 1 : imageY
        if edges(r,c) >  0

            edges(r,c) = equivVector(edges(r,c));
           
        end
        
    end
end

%edges = edges * 255;
classes = unique(edges); %Get a list of all of the classes in the image.
numClasses = size(classes); %Get the number of classes.
numClasses = numClasses(1)-1; %Subtract 1 because '0' is not a class, it is background.
%edgesdisp = uint8(edges);
%figure, imshow(edgesdisp);
maxclass = max(max(edges));
ccim = edges;
numbercc = numClasses;

%for r = 1 : imageX
%    for c = 1 : imageY
%        if edges(r,c) == 1
%            edges(r,c) = 70;
%        elseif edges(r,c) == 20
%            edges(r,c) = 150;
%        elseif edges(r,c) == 123
%            edges(r,c) = 255;
%        end
%    end
%end

%edgesdisp2 = uint8(edges);
%figure, imshow(edgesdisp2);

end