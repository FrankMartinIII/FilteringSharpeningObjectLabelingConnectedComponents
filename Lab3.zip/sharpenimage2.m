%Frank Martin and Ryan George 4/2/21
%sharpenimage2 is a function used to enhance detail in the image. It takes
%3 inputs: img, sigma, and alpha.
%img is the input greyscale image.
%sigma is the standard deviation used for the Gaussian which is used for
%smoothing the image.
%alpha is the value that the gradient magnitude is multiplied by when it is added
%to the original image to get the sharpened image.
%It returns dx, the gradient in the x direction, dy, the gradient in the y direction, sharpim, the sharpened image, smoothim, the image that was
%smoothed with the Gaussian filter, and gradMag, the magnitude of the
%gradient vectors calculated from the x and y gradients.

function [dx, dy, sharpim, smoothim, gradMag] = sharpenimage2(img, sigma, alpha)

%im = imread("pig.png");
%img = im2gray(im);

%figure , imshow(img);

%sigma = 1;
%alpha = 2;

imsmooth = imgaussfilt(img, sigma); %apply gaussian with specified sigma value to smooth the image.
[gradientx, gradienty] = imgradientxy(imsmooth); %calculate the gradient in the x and y direction.
[gradientMag, gradientDir] = imgradient(gradientx, gradienty); %get the gradient magnitude and direction from the directional gradients x and y.



gradientMag = uint8(gradientMag); 
imsharp = img + (alpha*gradientMag); %Sharpened image is calculated by adding the gradient magnitude multiplied by the alpha value to the original image.

dx = gradientx;
dy = gradienty;
sharpim = imsharp;
smoothim = imsmooth;
gradMag = gradientMag;


%figure, imshow(imsharp);
end